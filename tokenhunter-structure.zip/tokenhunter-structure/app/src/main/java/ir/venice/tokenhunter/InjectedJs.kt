package ir.venice.tokenhunter

import org.json.JSONArray
import org.json.JSONObject

object InjectedJs {

    private fun arr(list: List<String>) = JSONArray(list).toString()
    private fun quote(s: String) = JSONObject.quote(s)

    /** شنود fetch / XHR / هدر Authorization. idempotent. */
    fun interceptors(): String = """
        (function () {
          if (window.__thNet) return;
          window.__thNet = true;
          function push(url, headers, body) {
            try { TH.onNetwork(JSON.stringify({
              url: String(url || ''), headers: String(headers || ''), body: String(body || '')
            })); } catch (e) {}
          }
          var of = window.fetch;
          if (of) {
            window.fetch = function (input, init) {
              var url = (input && input.url) || input;
              return of.apply(this, arguments).then(function (res) {
                try { res.clone().text().then(function (t) { push(url, '', t); }); } catch (e) {}
                return res;
              });
            };
          }
          var oo = XMLHttpRequest.prototype.open;
          var os = XMLHttpRequest.prototype.send;
          var oh = XMLHttpRequest.prototype.setRequestHeader;
          XMLHttpRequest.prototype.open = function (m, u) { this.__u = u; this.__h = ''; return oo.apply(this, arguments); };
          XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
            this.__h += k + ': ' + v + '\n';
            return oh.apply(this, arguments);
          };
          XMLHttpRequest.prototype.send = function () {
            var self = this;
            this.addEventListener('load', function () {
              try { push(self.__u, self.__h, self.responseText); } catch (e) {}
            });
            return os.apply(this, arguments);
          };
        })();
    """.trimIndent()

    /** مقدارگذاری سازگار با React/Vue + سابمیت. */
    private fun fill(fields: List<String>, buttons: List<String>, value: String, skipIfOtpPresent: List<String>): String = """
        (function () {
          var fields = ${arr(fields)};
          var buttons = ${arr(buttons)};
          var skip = ${arr(skipIfOtpPresent)};
          var value = ${quote(value)};

          function visible(el) {
            return el && el.offsetParent !== null && !el.disabled && !el.readOnly;
          }
          function pick(list) {
            var found = [];
            list.forEach(function (sel) {
              try { document.querySelectorAll(sel).forEach(function (e) { found.push(e); }); } catch (e) {}
            });
            return found;
          }

          if (skip.length && pick(skip).some(visible)) {
            TH.log('فیلد OTP روی صفحه است؛ پر کردن شماره رد شد');
            return;
          }

          var target = pick(fields).filter(visible)[0] || pick(fields)[0];
          if (!target) { TH.log('فیلد ورودی پیدا نشد'); return; }

          target.focus();
          var proto = target.tagName === 'TEXTAREA'
            ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
          var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
          setter.call(target, value);
          target.dispatchEvent(new Event('input', { bubbles: true }));
          target.dispatchEvent(new Event('change', { bubbles: true }));
          target.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a' }));
          target.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
          target.blur();
          TH.log('فیلد پر شد: ' + value.length + ' کاراکتر');

          setTimeout(function () {
            var btn = pick(buttons).filter(visible)[0];
            if (btn) { btn.click(); TH.log('دکمه کلیک شد'); return; }
            if (target.form && target.form.requestSubmit) { target.form.requestSubmit(); return; }
            if (target.form) { target.form.submit(); return; }
            target.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
            TH.log('سابمیت با Enter');
          }, 500);
        })();
    """.trimIndent()

    fun fillPhone(op: OperatorConfig, phone: String) =
        fill(op.phoneFields, op.phoneButtons, phone, skipIfOtpPresent = op.otpFields)

    fun fillOtp(op: OperatorConfig, code: String) =
        fill(op.otpFields, op.otpButtons, code, skipIfOtpPresent = emptyList())

    /** پولینگ localStorage / sessionStorage / cookie. */
    fun pollStorage(): String = """
        (function () {
          if (window.__thPoll) return;
          window.__thPoll = true;
          var keyRe = /token|jwt|auth|sess|bearer|sid/i;
          var jwtRe = /eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/;
          function scan(store) {
            if (!store) return;
            for (var i = 0; i < store.length; i++) {
              var k = store.key(i);
              var v = store.getItem(k);
              if (!v) continue;
              var m = v.match(jwtRe);
              if (m) { TH.onToken('storage:' + k, m[0]); continue; }
              if (keyRe.test(k) && v.length >= 20 && v.length <= 4096 && !/\s/.test(v)) {
                TH.onToken('storage:' + k, v);
              }
            }
          }
          setInterval(function () {
            try {
              scan(localStorage);
              scan(sessionStorage);
              var m = document.cookie.match(jwtRe);
              if (m) TH.onToken('cookie', m[0]);
            } catch (e) {}
          }, 800);
        })();
    """.trimIndent()
}