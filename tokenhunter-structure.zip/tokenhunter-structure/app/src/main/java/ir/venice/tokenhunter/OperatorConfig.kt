package ir.venice.tokenhunter

data class OperatorConfig(
    val title: String,
    val startUrl: String,
    val senderHints: List<String>,
    val phoneFields: List<String>,
    val phoneButtons: List<String>,
    val otpFields: List<String>,
    val otpButtons: List<String>
) {
    override fun toString() = title
}

object Operators {

    private val genericPhoneFields = listOf(
        "input[type=tel]",
        "input[autocomplete=tel]",
        "input[name*=mobile i]",
        "input[id*=mobile i]",
        "input[name*=phone i]",
        "input[type=text]"
    )

    private val genericOtpFields = listOf(
        "input[autocomplete=one-time-code]",
        "input[name*=otp i]",
        "input[name*=code i]",
        "input[id*=otp i]",
        "input[type=tel]",
        "input[inputmode=numeric]",
        "input[type=text]"
    )

    private val genericButtons = listOf(
        "button[type=submit]",
        "input[type=submit]",
        "button[id*=submit i]",
        "button[id*=login i]",
        "button[id*=confirm i]",
        "button[id*=verify i]",
        "button[id*=continue i]",
        "button"
    )

    val MCI = OperatorConfig(
        title = "همراه اول",
        startUrl = "https://my.mci.ir/",
        senderHints = listOf("MCI", "همراه اول", "MCINET", "9830", "3000"),
        phoneFields = genericPhoneFields,
        phoneButtons = genericButtons,
        otpFields = genericOtpFields,
        otpButtons = genericButtons
    )

    val IRANCELL = OperatorConfig(
        title = "ایرانسل",
        startUrl = "https://my.irancell.ir/",
        senderHints = listOf("Irancell", "IRANCELL", "MTN", "9835", "IRNCELL"),
        phoneFields = genericPhoneFields,
        phoneButtons = genericButtons,
        otpFields = genericOtpFields,
        otpButtons = genericButtons
    )

    val all = listOf(MCI, IRANCELL)
}