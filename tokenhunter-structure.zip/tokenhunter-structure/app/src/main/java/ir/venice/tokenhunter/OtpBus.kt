package ir.venice.tokenhunter

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

sealed interface OtpEvent {
    data class Code(val code: String, val sender: String, val body: String) : OtpEvent
    data class Ignored(val reason: String) : OtpEvent
}

object OtpBus {

    private val _events = MutableSharedFlow<OtpEvent>(extraBufferCapacity = 16)
    val events = _events.asSharedFlow()

    /** پیامک‌های قدیمی‌تر از این لحظه نادیده گرفته می‌شوند. */
    @Volatile var acceptSince: Long = 0L

    /** لیست سفید فرستنده؛ خالی = همه. */
    @Volatile var senderFilter: List<String> = emptyList()

    fun publish(event: OtpEvent) {
        _events.tryEmit(event)
    }
}