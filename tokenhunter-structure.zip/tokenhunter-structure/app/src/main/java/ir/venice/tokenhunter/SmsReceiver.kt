package ir.venice.tokenhunter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

class SmsReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "SmsReceiver"
        private const val MAX_AGE_MS = 5 * 60 * 1000L

        /** ۶ رقم که قبل و بعدش رقم نباشد. */
        private val CODE_REGEX = Regex("(?<!\\d)(\\d{6})(?!\\d)")

        private val DIGIT_MAP: Map<Char, Char> = buildMap {
            "۰۱۲۳۴۵۶۷۸۹".forEachIndexed { i, c -> put(c, ('0' + i)) }
            "٠١٢٣٤٥٦٧٨٩".forEachIndexed { i, c -> put(c, ('0' + i)) }
        }

        private fun normalizeDigits(s: String) = buildString(s.length) {
            s.forEach { append(DIGIT_MAP[it] ?: it) }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (parts.isEmpty()) return

        val now = System.currentTimeMillis()

        // پیامک چندبخشی: بر اساس فرستنده گروه‌بندی و بدنه‌ها به هم چسبانده می‌شوند.
        parts.filterNotNull()
            .groupBy { it.displayOriginatingAddress?.trim().orEmpty() }
            .forEach { (sender, group) ->

                val timestamp = group.maxOf { it.timestampMillis }

                if (timestamp < OtpBus.acceptSince - 5_000L) {
                    OtpBus.publish(OtpEvent.Ignored("پیامک قدیمی ($sender)"))
                    return@forEach
                }
                if (now - timestamp > MAX_AGE_MS) {
                    OtpBus.publish(OtpEvent.Ignored("منقضی ($sender)"))
                    return@forEach
                }
                if (!senderAllowed(sender)) {
                    OtpBus.publish(OtpEvent.Ignored("فرستنده مجاز نیست ($sender)"))
                    return@forEach
                }

                val body = normalizeDigits(group.joinToString("") { it.displayMessageBody.orEmpty() })
                val match = CODE_REGEX.find(body)
                if (match == null) {
                    OtpBus.publish(OtpEvent.Ignored("کد ۶ رقمی یافت نشد ($sender)"))
                    return@forEach
                }

                Log.d(TAG, "OTP از $sender")
                OtpBus.publish(OtpEvent.Code(match.groupValues[1], sender, body))
                return
            }
    }

    private fun senderAllowed(sender: String): Boolean {
        val filter = OtpBus.senderFilter
        if (filter.isEmpty()) return true
        val s = normalizeDigits(sender).lowercase()
        return filter.any { hint ->
            val h = hint.lowercase()
            s == h || s.contains(h) || s.endsWith(h)
        }
    }
}