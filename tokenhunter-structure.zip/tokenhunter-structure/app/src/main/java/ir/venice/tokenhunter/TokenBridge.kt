package ir.venice.tokenhunter

import android.util.Log
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.util.Collections

data class TokenHit(val value: String, val source: String)

class TokenBridge(private val listener: Listener) {

    fun interface Listener {
        fun onToken(hit: TokenHit)
    }

    companion object {
        private const val TAG = "TokenBridge"
        private const val MIN_LEN = 12
        private const val MAX_LEN = 8192
    }

    private val seen: MutableSet<String> = Collections.synchronizedSet(mutableSetOf())

    private val jwt = Regex("eyJ[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}")
    private val bearer = Regex("Bearer\\s+([A-Za-z0-9._\\-]{${MIN_LEN},$MAX_LEN})")
    private val jsonKey = Regex(
        "\"?([A-Za-z_]*(?:access_?token|refresh_?token|id_?token|token|jwt|session_?id|auth_?token|sid))\"?\\s*[:=]\\s*\"([^\"]{${MIN_LEN},$MAX_LEN})\"",
        RegexOption.IGNORE_CASE
    )

    @JavascriptInterface
    fun onNetwork(payloadJson: String) {
        val obj = runCatching { JSONObject(payloadJson) }.getOrNull() ?: return
        val url = obj.optString("url").take(200)
        val body = obj.optString("body")
        val headers = obj.optString("headers")

        scan(jwt, body, "jwt @ $url", group = 0)
        scan(bearer, headers + "\n" + body, "bearer @ $url", group = 1)
        scan(jsonKey, body, "json @ $url", group = 2)
    }

    @JavascriptInterface
    fun onToken(kind: String, value: String) {
        emit(value, kind)
    }

    @JavascriptInterface
    fun log(message: String) {
        Log.d(TAG, message)
    }

    private fun scan(regex: Regex, haystack: String, label: String, group: Int) {
        if (haystack.isEmpty()) return
        regex.findAll(haystack).take(6).forEach { m ->
            val value = m.groupValues.getOrNull(group)?.trim().orEmpty()
            emit(value, label)
        }
    }

    private fun emit(rawValue: String, source: String) {
        val value = rawValue.trim()
        if (value.length < MIN_LEN || value.length > MAX_LEN) return
        if (!seen.add(value)) return
        Log.d(TAG, "توکن از [$source] — ${value.length} کاراکتر")
        listener.onToken(TokenHit(value, source))
    }
}